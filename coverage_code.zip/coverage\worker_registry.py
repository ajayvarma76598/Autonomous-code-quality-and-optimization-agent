class WorkerRegistry:
    WORKERS = {
        "python": "python-coverage-worker",
        "java": "java-coverage-worker",
        "javascript": "js-coverage-worker",
        "typescript": "ts-coverage-worker",
        "go": "go-coverage-worker",
        "rust": "rust-coverage-worker",
        "unknown": "python-coverage-worker" # Fallback
    }

    @classmethod
    def get(cls, language: str) -> str:
        # If multiple languages are passed (e.g. "javascript/typescript, python"), 
        # take the first one or prioritize backend.
        if not language or language == "unknown":
            return cls.WORKERS["unknown"]
            
        primary_lang = [l.strip() for l in language.split(",")][0]
        
        # Normalize mapping
        if "javascript" in primary_lang or "typescript" in primary_lang:
            if "typescript" in primary_lang:
                return cls.WORKERS["typescript"]
            return cls.WORKERS["javascript"]
            
        return cls.WORKERS.get(primary_lang.lower(), cls.WORKERS["unknown"])

worker_registry = WorkerRegistry()
