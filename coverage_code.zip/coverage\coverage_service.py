from pathlib import Path
from dataclasses import dataclass
import subprocess

@dataclass
class CoverageResult:
    success: bool
    exit_code: int
    stdout: str
    stderr: str

class CoverageService:
    def run(self, repo_path: Path, worker_image: str) -> CoverageResult:
        if not repo_path.exists():
            raise FileNotFoundError(f"Repository not found: {repo_path}")
            
        if not repo_path.is_dir():
            raise ValueError(f"Repository path is not a directory: {repo_path}")

        # Convert path to absolute string for Docker mount
        repo_path_str = str(repo_path.absolute())
        
        try:
            # Execute the docker run command
            result = subprocess.run(
                [
                    "docker", "run", "--rm",
                    "-v", f"{repo_path_str}:/workspace",
                    worker_image
                ],
                capture_output=True,
                text=True,
                timeout=1800
            )
            
            return CoverageResult(
                success=result.returncode == 0,
                exit_code=result.returncode,
                stdout=result.stdout,
                stderr=result.stderr
            )
        except subprocess.TimeoutExpired as e:
            return CoverageResult(
                success=False,
                exit_code=-1,
                stdout=str(e.stdout) if e.stdout else "",
                stderr=f"Worker timed out after {e.timeout} seconds."
            )
