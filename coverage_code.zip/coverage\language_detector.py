from pathlib import Path
import os
import logging

logger = logging.getLogger(__name__)

class LanguageDetector:
    def detect(self, repo_path: Path) -> str:
        """
        Detect the primary language of a repository by inspecting ecosystem files.
        Returns a string like 'python', 'java', 'javascript', 'go', 'rust', or 'unknown'.
        """
        if not repo_path.exists() or not repo_path.is_dir():
            return "unknown"
            
        repo_path_str = str(repo_path)
        try:
            files = os.listdir(repo_path_str)
            
            if any(f in files for f in ["pom.xml", "build.gradle", "build.gradle.kts"]): 
                return "java"
            if any(f in files for f in ["package.json", "yarn.lock"]): 
                if "tsconfig.json" in files:
                    return "typescript"
                return "javascript"
            if any(f in files for f in ["requirements.txt", "pyproject.toml", "setup.py", "Pipfile"]): 
                return "python"
            if "go.mod" in files: 
                return "go"
            if "Cargo.toml" in files: 
                return "rust"
            if "composer.json" in files: 
                return "php"
            if "Gemfile" in files: 
                return "ruby"
            if any(f.endswith(".sln") or f.endswith(".csproj") for f in files): 
                return "csharp"
            
            # Fallback to counting extensions
            ext_counts = {}
            for root, _, fs in os.walk(repo_path_str):
                if '.git' in root or 'node_modules' in root or '.venv' in root: 
                    continue
                for f in fs:
                    ext = os.path.splitext(f)[1].lower()
                    if ext in [".py", ".java", ".js", ".ts", ".go", ".rs", ".php", ".rb", ".cs", ".cpp", ".c"]:
                        ext_counts[ext] = ext_counts.get(ext, 0) + 1
            
            if ext_counts:
                ext_map = {
                    ".py": "python", ".java": "java", ".js": "javascript", ".ts": "typescript", 
                    ".go": "go", ".rs": "rust", ".php": "php", ".rb": "ruby", ".cs": "csharp", 
                    ".cpp": "c++", ".c": "c"
                }
                top_ext = max(ext_counts, key=ext_counts.get)
                return ext_map.get(top_ext, "unknown")
                
        except Exception as e:
            logger.warning(f"Language detection failed: {e}")
            
        return "unknown"
